const mongoose=require('mongoose')
const apiSchema=new mongoose.Schema(
    {
        id: {type: Number, required: ''},
        title: {type: String, required: ''},
        description: { type: String, required: ''},
        category: {type: String, required: ''},
        image: {type: String, required: ''},
        sold : {type: String, required: ''},
        dateOfSale: {type: Date, required: ''}
    },
    {
        timestamps: true
    }
)

const ApiModel=mongoose.model('apiItems',apiSchema)

module.exports=ApiModel