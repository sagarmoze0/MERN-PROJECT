const express=require('express')
const axios=require('axios')
const ApiModel=require('../models/apiItems')
const router=express.Router()

router.get('/database', async (req,res)=>{
    try{
        const response = await axios.get('https://s3.amazonaws.com/roxiler.com/product_transaction.json');
        const data=response.data
        await ApiModel.insertMany(data); 
        res.send('Database initialized with seed data')
    }
    catch(error){
        res.status(400).send(error)
    }
})

router.get('/transactions', async (req, res) => {
    try {
        const { search, month, page = 1, perPage = 10 } = req.query;
        let query = {};
        if (month) {
            const monthRegex = new RegExp(month, 'i'); 
            query.dateOfSale = { $regex: monthRegex };
        }
        if (search) {
                        query = {
                $or: [
                    { title: { $regex: search, $options: 'i' } },
                    { description: { $regex: search, $options: 'i' } }
                ]
            };
        }
        const skip = (page - 1) * perPage;
        let transactions;
        if (search) {
            transactions = await ApiModel.find(query).skip(skip).limit(Number(perPage));
        } else {
            transactions = await ApiModel.find().skip(skip).limit(Number(perPage));
        }
        res.status(200).json(transactions);
    } catch (error) {
        console.error('Error fetching transactions:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

const filterByMonth=(transaction, month)=>{
    return transaction.filter(transaction=>{
        const transDate=new Date(transaction.dateOfSale)
        return transDate.getMonth() === month;
    })
}
router.get('/statistics',(req,res)=>{
   const {month}=req.query
   const selectMonth=new Date(month).getMonth()

   const filteredTransactions= filterByMonthtransacti(transaction, selectMonth)

   const totalAmount=filteredTransactions.reduce((total,transaction)=>{
    
   })
})

module.exports=router